<?php

    /**
     * @author Jorge Castro <jorgecastrot2005@gmail.com>
     */
    
    $nombre = readline('Dame un nombre: ');
    
    print "Hola $nombre, encantado de conocerte\n";

?>