<?php

    /**
     * @author Jorge Castro <jorgecastrot2005@gmail.com>
    */

    $rando = rand(1, 5);

    if ($rando == 1) {
        print("$rando - uno\n");
    }elseif($rando == 2){
        print("$rando - dos\n");
    }elseif($rando == 3){
        print("$rando - tres\n");
    }elseif($rando == 4){
        print("$rando - cuatro\n");
    }else{
        print("$rando - cinco\n");
    }

?>