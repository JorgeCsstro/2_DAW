<?php

    /**
     * @author Jorge Castro <jorgecastrot2005@gmail.com>
    */

    $euro = readline("Dame una cantidad de Euros: ");

    $conversion = $euro * 166.386;

    print($euro . "€ son " . $conversion . " pesetas\n");

?>