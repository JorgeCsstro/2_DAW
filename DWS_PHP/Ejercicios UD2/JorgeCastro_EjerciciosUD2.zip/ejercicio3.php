<?php 

    $nombre = readline('Dame un nombre: ');

    print "Hola " . $nombre . ", encantado de conocerte\n" . "¡Gracias por la visita!";

?>