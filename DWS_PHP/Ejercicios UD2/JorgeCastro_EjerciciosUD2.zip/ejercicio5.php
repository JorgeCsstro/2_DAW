<?php

    /**
     * @author Jorge Castro <jorgecastrot2005@gmail.com>
     */
    
    $num1 = readline('Dame un número decimal: ');
    
    $redondeado = round($num1);
    
    print "El número introducido es: $num1\n" . "Redondeado: $redondeado\n";

?>