<?php

    /**
     * @author Jorge Castro <jorgecastrot2005@gmail.com>
    */

    $rando = rand(10, 90);

    print("La cantidad es de $rando\n");

?>